N,M = map(int,input().split())
#1
test1 = []
for _ in range(M):
    for _ in range(N):
        